package xiaozhi.common.utils;

import org.springframework.stereotype.Component;

/**
 * 获取配置文件信息
 * Copyright xin-nan.com
 */
@Component
public class PropertiesUtils {
}
